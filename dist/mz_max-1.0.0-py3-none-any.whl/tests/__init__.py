"""
Test suite for MZ Max

This package contains comprehensive tests for all MZ Max modules
including unit tests, integration tests, and performance tests.
"""

__version__ = "1.0.0"
